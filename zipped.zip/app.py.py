from flask import Flask, render_template, request, jsonify, redirect, session
import os
import json
import re
import random
import time
import uuid
import requests
from bs4 import BeautifulSoup

# ========= STEP 2 FIX FOR RENDER =========
# Force Dialogflow key to load (important for Render deployment)
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "dialogflow-access-key.json"

# Dialogflow import
try:
    from google.cloud import dialogflow_v2 as dialogflow
except Exception as e:
    dialogflow = None
    print("Warning: google-cloud-dialogflow not available:", e)

# ========== Configuration ==========
PROJECT_ID = "unihelpai-ohyd"
LANGUAGE_CODE = "en"
CACHE_TTL = 30 * 60
JIUNGE_PORTAL = "https://jiunge.kibu.ac.ke/"

app = Flask(__name__)
app.secret_key = os.environ.get("KIBUAI_SECRET", "kibuai-secret")

# ========= Load local intents =========
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
INTENT_PATH = os.path.join(BASE_DIR, "school_fees.json")

if not os.path.exists(INTENT_PATH):
    raise FileNotFoundError("Missing school_fees.json")

with open(INTENT_PATH, "r", encoding="utf-8") as f:
    LOCAL_INTENTS = json.load(f).get("intents", [])

# ========= Utilities =========
def normalize_text(txt):
    if not txt:
        return ""
    txt = txt.lower()
    txt = re.sub(r"[^a-z0-9\s\/]", " ", txt)
    return re.sub(r"\s+", " ", txt).strip()

def pattern_to_regex(pat):
    pat = re.escape(pat.lower().strip())
    pat = pat.replace(r"\ ", r"\s+")
    return r"\b" + pat + r"\b"

def match_local_intent(user_input):
    text = normalize_text(user_input)
    for intent in LOCAL_INTENTS:
        for pat in intent.get("patterns", []):
            try:
                regex = pattern_to_regex(pat)
                if re.search(regex, text):
                    return intent.get("tag"), random.choice(intent.get("responses", []))
            except:
                if pat.lower() in text:
                    return intent.get("tag"), random.choice(intent.get("responses", []))
    return None, None

def extract_reg_no(text):
    m = re.search(r"[A-Za-z]{2,10}\/\d{2,6}\/\d{2}", text)
    return m.group(0) if m else None

def extract_amount(text):
    m = re.search(r"\b\d{2,7}\b", text)
    return m.group(0) if m else None

# ========= Scraper Engine =========
SCRAPE_CACHE = {}

def scrape_kibu_endpoint(endpoint):
    base = "https://kibu.ac.ke/"
    url = base + endpoint.lstrip("/")
    now = time.time()

    if url in SCRAPE_CACHE:
        data, ts = SCRAPE_CACHE[url]
        if now - ts < CACHE_TTL:
            return data

    try:
        r = requests.get(url, timeout=10)
        soup = BeautifulSoup(r.text, "html.parser")

        headlines = []
        for article in soup.find_all("article")[:8]:
            h = article.find(["h1", "h2", "h3"])
            if h:
                title = h.get_text(strip=True)
                a = article.find("a", href=True)
                link = base.rstrip("/") + a["href"] if a else ""
                headlines.append(f"• {title}\n  {link}")

        if headlines:
            text = "\n\n".join(headlines)
        else:
            text = soup.get_text(" ", strip=True)[:800]

        SCRAPE_CACHE[url] = (text, now)
        return text
    except:
        return None

def scrape_news(): return scrape_kibu_endpoint("category/news/")
def scrape_events(): return scrape_kibu_endpoint("category/events/")
def scrape_admissions(): return scrape_kibu_endpoint("admissions/")
def scrape_timetable(): return scrape_kibu_endpoint("timetable/")
def scrape_hostels(): return scrape_kibu_endpoint("hostels/")
def scrape_library(): return scrape_kibu_endpoint("library/")
def scrape_tenders(): return scrape_kibu_endpoint("tenders/")
def scrape_downloads(): return scrape_kibu_endpoint("downloads/")

# ========= Dialogflow Reply =========
def dialogflow_reply(text, session_id=None):
    if dialogflow is None:
        return None
    try:
        session_client = dialogflow.SessionsClient()
        session_id = session_id or str(uuid.uuid4())
        session_path = session_client.session_path(PROJECT_ID, session_id)

        text_input = dialogflow.TextInput(text=text, language_code=LANGUAGE_CODE)
        query_input = dialogflow.QueryInput(text=text_input)
        response = session_client.detect_intent(
            request={"session": session_path, "query_input": query_input}
        )

        return response.query_result.fulfillment_text or None
    except Exception as e:
        print("Dialogflow error:", e)
        return None

# ========= Chatbot Route =========
@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json() or {}
    message = data.get("message", "").strip()
    if not message:
        return jsonify({"reply": "Please type something 😊"})

    msg_norm = normalize_text(message)

    # ensure dialogflow session
    if "df_session" not in session:
        session["df_session"] = str(uuid.uuid4())

    reg = extract_reg_no(message)
    amt = extract_amount(message)
    last = session.get("last_topic")

    # ========== Payment Flow ==========
    if "pay" in msg_norm and "fee" in msg_norm:
        session["last_topic"] = "payment"

        if reg and amt:
            session.pop("last_topic", None)
            reply = f"Redirecting to Jiunge to complete payment of {amt} for {reg}."
            return jsonify({"reply": reply, "redirect_url": JIUNGE_PORTAL})

        if reg:
            session["reg_no"] = reg
            return jsonify({"reply": f"Okay, noted {reg}. How much would you like to pay?"})

        return jsonify({"reply": "Provide your registration number (e.g., BCOM/0000/23)."})

    if last == "payment" and reg:
        session["reg_no"] = reg
        return jsonify({"reply": f"Good. Now how much would you like to pay for {reg}?"})

    if last == "payment" and amt:
        reg = session.get("reg_no")
        if not reg:
            return jsonify({"reply": "Please give the registration number first."})

        session.pop("last_topic", None)
        session.pop("reg_no", None)
        reply = f"Redirecting to Jiunge to complete payment of {amt} for {reg}."
        return jsonify({"reply": reply, "redirect_url": JIUNGE_PORTAL})

    # ========== Scraper ==========
    if "news" in msg_norm:
        t = scrape_news()
        return jsonify({"reply": "Latest News:\n\n" + (t or "Not available.")})

    if "event" in msg_norm:
        t = scrape_events()
        return jsonify({"reply": "Upcoming Events:\n\n" + (t or "Not available.")})

    if "admission" in msg_norm:
        t = scrape_admissions()
        return jsonify({"reply": "Admissions Info:\n\n" + (t or "Not available.")})

    # ========== Local Intents ==========
    tag, local_resp = match_local_intent(message)
    if tag:
        session["last_topic"] = tag
        return jsonify({"reply": local_resp})

    # ========== Dialogflow fallback ==========
    df = dialogflow_reply(message, session["df_session"])
    if df:
        return jsonify({"reply": df})

    return jsonify({"reply": "I didn't understand that. Please rephrase."})

# ========= UI =========
@app.route("/")
def home():
    try:
        return render_template("index.html")
    except:
        return "<h2>KibuAI backend running. index.html missing.</h2>"

@app.route("/redirect_jiunge")
def red_j():
    return redirect(JIUNGE_PORTAL)

# ========= Run (Render compatible) =========
if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port)
